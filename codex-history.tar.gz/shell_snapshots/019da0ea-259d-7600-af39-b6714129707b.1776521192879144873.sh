# Snapshot file
# Unset all aliases to avoid conflicts with functions
# Functions

# setopts 3
set -o braceexpand
set -o hashall
set -o interactive-comments

# aliases 0

# exports 35
declare -x APPLICATION_INSIGHTS_NO_STATSBEAT="true"
declare -x BROWSER="/root/.vscode-server/cli/servers/Stable-560a9dba96f961efea7b1612916f89e5d5d4d679/server/bin/helpers/browser.sh"
declare -x CODEX_INTERNAL_ORIGINATOR_OVERRIDE="codex_vscode"
declare -x DEBUG="release"
declare -x ELECTRON_RUN_AS_NODE="1"
declare -x HOME="/root"
declare -x HTTPS_PROXY="http://127.0.0.1:7897"
declare -x HTTP_PROXY="http://127.0.0.1:7897"
declare -x LESSCLOSE="/usr/bin/lesspipe %s %s"
declare -x LESSOPEN="| /usr/bin/lesspipe %s"
declare -x LOGNAME="root"
declare -x LS_COLORS=""
declare -x MOTD_SHOWN="pam"
declare -x NODE_TLS_REJECT_UNAUTHORIZED="0"
declare -x NVM_BIN="/usr/local/nvm/versions/node/v16.20.2/bin"
declare -x NVM_CD_FLAGS=""
declare -x NVM_DIR="/usr/local/nvm"
declare -x NVM_INC="/usr/local/nvm/versions/node/v16.20.2/include/node"
declare -x PATH="/root/.codex/tmp/arg0/codex-arg0g7f97m:/root/.vscode-server/cli/servers/Stable-560a9dba96f961efea7b1612916f89e5d5d4d679/server/bin/remote-cli:/usr/local/nvm/versions/node/v16.20.2/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin:/root/.vscode-server/extensions/openai.chatgpt-26.415.20818-linux-x64/bin/linux-x86_64"
declare -x RUST_LOG="warn"
declare -x SHELL="/bin/bash"
declare -x SHLVL="2"
declare -x SSH_CLIENT="10.223.18.85 10627 36155"
declare -x SSH_CONNECTION="10.223.18.85 10627 10.176.34.112 36155"
declare -x USER="root"
declare -x VSCODE_AGENT_FOLDER="/root/.vscode-server"
declare -x VSCODE_CLI_REQUIRE_TOKEN="13f4eae6-5028-4212-b58d-27eeaa185eef"
declare -x VSCODE_CWD="/root"
declare -x VSCODE_ESM_ENTRYPOINT="vs/workbench/api/node/extensionHostProcess"
declare -x VSCODE_HANDLES_SIGPIPE="true"
declare -x VSCODE_HANDLES_UNCAUGHT_ERRORS="true"
declare -x VSCODE_IPC_HOOK_CLI="/tmp/vscode-ipc-02af7853-e792-4db3-b756-6c2e6ee5d1aa.sock"
declare -x VSCODE_NLS_CONFIG="{\"userLocale\":\"zh-cn\",\"osLocale\":\"zh-cn\",\"resolvedLanguage\":\"zh-cn\",\"defaultMessagesFile\":\"/root/.vscode-server/cli/servers/Stable-560a9dba96f961efea7b1612916f89e5d5d4d679/server/out/nls.messages.json\",\"languagePack\":{\"translationsConfigFile\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn/tcf.json\",\"messagesFile\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn/560a9dba96f961efea7b1612916f89e5d5d4d679/nls.messages.json\",\"corruptMarkerFile\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn/corrupted.info\"},\"locale\":\"zh-cn\",\"availableLanguages\":{\"*\":\"zh-cn\"},\"_languagePackId\":\"b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn\",\"_languagePackSupport\":true,\"_translationsConfigFile\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn/tcf.json\",\"_cacheRoot\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn\",\"_resolvedLanguagePackCoreLocation\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn/560a9dba96f961efea7b1612916f89e5d5d4d679\",\"_corruptedFile\":\"/root/.vscode-server/data/clp/b3d577d0e0e421f69f6e9379a6ee9c57.zh-cn/corrupted.info\"}"
declare -x VSCODE_RECONNECTION_GRACE_TIME="10800000"
declare -x _CUDA_COMPAT_PATH="/usr/local/cuda/compat"
